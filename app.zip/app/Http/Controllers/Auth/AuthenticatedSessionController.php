<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /** Show the login screen. */
    public function create(): View
    {
        return view('auth.login');
    }

    /** Handle an incoming authentication request. */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();
        $request->session()->regenerate();

        $user = Auth::user();
        $user->forceFill(['last_login_at' => now()])->save();

        return redirect()->intended(route('dashboard'))->with('toast', [
            'message' => 'Selamat datang kembali, '.$user->name.'!',
            'type' => 'success',
        ]);
    }

    /** Destroy an authenticated session. */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('toast', [
            'message' => 'Anda telah keluar.',
            'type' => 'info',
        ]);
    }
}
